CREATE TABLE cart (

    id BIGINT PRIMARY KEY AUTO_INCREMENT,

    user_id BIGINT NOT NULL,

    product_id BIGINT NOT NULL,

    quantity INT NOT NULL,

    created_at TIMESTAMP,

    CONSTRAINT fk_cart_user
    FOREIGN KEY (user_id)
    REFERENCES users(id),

    CONSTRAINT fk_cart_product
    FOREIGN KEY (product_id)
    REFERENCES products(id)
);
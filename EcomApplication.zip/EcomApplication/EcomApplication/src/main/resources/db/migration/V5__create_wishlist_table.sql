CREATE TABLE wishlist (
 
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
 
    user_id BIGINT NOT NULL,
 
    product_id BIGINT NOT NULL,
 
    created_at TIMESTAMP,
 
    CONSTRAINT fk_wishlist_user
    FOREIGN KEY (user_id)
    REFERENCES users(id),
 
    CONSTRAINT fk_wishlist_product
    FOREIGN KEY (product_id)
    REFERENCES products(id)
);

INSERT INTO users (full_name, email, password, role, enabled, created_at) VALUES
('Alice', 'alice@example.com', 'password123', 'CUSTOMER', TRUE, NOW()),
('Bob', 'bob@example.com', 'securepass', 'CUSTOMER', TRUE, NOW()),
('Charlie', 'charlie@example.com', 'adminpass', 'ADMIN', TRUE, NOW());


INSERT INTO categories (name) VALUES
('Electronics'),
('Books'),
('Clothing'),
('Home & Kitchen');

INSERT INTO products (name, description, price, quantity, category_id) VALUES
('Smartphone', 'Latest Android smartphone with 128GB storage', 29999.00, 50, 1),
('Laptop', 'Lightweight laptop with 16GB RAM', 69999.00, 20, 1),
('Novel', 'Best-selling fiction novel', 499.00, 100, 2),
('T-Shirt', 'Cotton round-neck t-shirt', 399.00, 200, 3),
('Mixer Grinder', '3-jar kitchen mixer grinder', 2499.00, 30, 4);



INSERT INTO wishlist (user_id, product_id, created_at) VALUES
(1, 1, NOW()),  -- Alice wants Smartphone
(1, 3, NOW()),  -- Alice wants Novel
(2, 2, NOW()),  -- Bob wants Laptop
(3, 4, NOW());  -- Charlie wants T-Shirt

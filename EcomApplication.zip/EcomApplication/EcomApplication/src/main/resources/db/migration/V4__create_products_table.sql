CREATE TABLE products (
 
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
 
    name VARCHAR(255) NOT NULL,
 
    description VARCHAR(1000),
 
    price DECIMAL(10,2) NOT NULL,
 
    quantity INT NOT NULL,
 
    category_id BIGINT,
 
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 
    CONSTRAINT fk_product_category
    FOREIGN KEY (category_id)
    REFERENCES categories(id)
 
);
package com.wishlist.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.product.model.Product;
import com.user.entity.User;
import com.wishlist.model.Wishlist;

@Repository
public interface WishlistRepository extends JpaRepository<Wishlist, Long> {

	List<Wishlist> findByUser(User user);

	List<Wishlist> findByUserAndProduct(User user, Product product);

	boolean existsByUserAndProduct(User user, Product product);

}

package com.wishlist.dto.response;

import com.product.dto.response.CategoryResponseDto;
import com.product.dto.response.ProductResponseDto;

public class WishlistResponseRetrive {

	private ProductResponseDto product;

	public ProductResponseDto getProduct() {
		return product;
	}

	public void setProduct(ProductResponseDto product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "WishlistResponseRetrive [product=" + product + "]";
	}

	public WishlistResponseRetrive(ProductResponseDto product) {
		super();
		this.product = product;
	}

	public WishlistResponseRetrive() {
		super();
	}

}

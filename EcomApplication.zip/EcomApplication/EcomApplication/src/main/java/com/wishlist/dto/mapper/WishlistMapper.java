package com.wishlist.dto.mapper;

import java.time.LocalDateTime;

import com.product.model.Product;
import com.user.entity.User;
import com.wishlist.dto.request.WishListRequestDto;
import com.wishlist.dto.response.WishListResponseDto;
import com.wishlist.model.Wishlist;

public class WishlistMapper {

	public static WishListResponseDto toResponse(Wishlist wishlist) {
		WishListResponseDto wishListResponseDto = new WishListResponseDto();
		wishListResponseDto.setId(wishlist.getId());
		return wishListResponseDto;
	};

	public static Wishlist toEntity(WishListRequestDto wishListRequestDto, User user, Product product) {
		Wishlist wishlist = new Wishlist();
		user.setUserid(wishListRequestDto.getUser());
		wishlist.setProduct(product);
		wishlist.setUser(user);
		return wishlist;
	}

}

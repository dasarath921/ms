package com.wishlist.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.product.Exception.ProductNotFoundException;
import com.product.model.Product;
import com.product.repository.ProductRepository;
import com.user.entity.User;
import com.user.exception.UserNotFoundException;
import com.user.repository.UserRepository;
import com.wishlist.Exception.WishlistAlreadyExistsException;
import com.wishlist.dto.mapper.WishListResponseMapper;
import com.wishlist.dto.mapper.WishlistMapper;
import com.wishlist.dto.request.WishListRequestDto;
import com.wishlist.dto.response.WishListResponseDto;
import com.wishlist.dto.response.WishlistResponseRetrive;
import com.wishlist.model.Wishlist;
import com.wishlist.repository.WishlistRepository;
import com.wishlist.service.wishlistService;

import jakarta.transaction.Transactional;

@Transactional
@Service
public class WishListServiceImpl implements wishlistService {

	private final WishlistRepository wishListRepository;

	private final ProductRepository productRepository;

	private final UserRepository userRepository;

	public WishListServiceImpl(WishlistRepository repository, ProductRepository productRepository,
			UserRepository userRepository) {
		this.wishListRepository = repository;
		this.productRepository = productRepository;
		this.userRepository = userRepository;
	}

	@Transactional
	@Override
	public WishListResponseDto createWishList(WishListRequestDto wishListRequestDto) {

		User user = userRepository.findById(wishListRequestDto.getUser())
				.orElseThrow(() -> new UserNotFoundException("User Not Found"));

		Product product = productRepository.findById(wishListRequestDto.getProduct())
				.orElseThrow(() -> new ProductNotFoundException("Product Not Found"));
		
		boolean	 exists = wishListRepository.existsByUserAndProduct(user, product);
		
		if(exists) {
			throw new WishlistAlreadyExistsException("Product already exists in wishlist");
		}

		Wishlist wishlist = WishlistMapper.toEntity(wishListRequestDto,user,product);
		wishlist.setLocalDateTime(LocalDateTime.now());
		Wishlist savedList = wishListRepository.save(wishlist);
		

		WishListResponseDto dto = WishlistMapper.toResponse(savedList);
		dto.setDescription("Product added to wishlist successfully");

		return dto;
	}

	@Override
	public List<WishlistResponseRetrive> getUserWithList(Long userId) {
		
		User user = userRepository.findById(userId).orElseThrow(() -> new UserNotFoundException("User Not Found"));

	
		List<Wishlist> wishlists = wishListRepository.findByUser(user);

		return wishlists.stream().map(WishListResponseMapper::toResponseRetrive).toList();

	}

	@Override
	public List<WishlistResponseRetrive> getUserWithListByProductId(Long userId, Long productId) {

		User user = userRepository.findById(userId).orElseThrow(() -> new UserNotFoundException("User Not Found"));

		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ProductNotFoundException("Product Not Found"));

		List<Wishlist> wishlists = wishListRepository.findByUserAndProduct(user, product);
		return wishlists.stream().map(WishListResponseMapper::toResponseRetrive).toList();
	}


}

package com.wishlist.Exception;

public class WishlistAlreadyExistsException extends RuntimeException {
	public WishlistAlreadyExistsException(String message) {
		super(message);
	}

}

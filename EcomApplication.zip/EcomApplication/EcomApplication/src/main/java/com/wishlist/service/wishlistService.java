package com.wishlist.service;


public interface wishlistService {

}

package com.wishlist.service;
import java.util.List;

import com.wishlist.dto.request.WishListRequestDto;
import com.wishlist.dto.response.WishListResponseDto;
import com.wishlist.dto.response.WishlistResponseRetrive;

public interface wishlistService{
	
	public WishListResponseDto createWishList(WishListRequestDto wishListRequestDto);
	
	public List<WishlistResponseRetrive> getUserWithList(Long userId);
	public List<WishlistResponseRetrive> getUserWithListByProductId(Long userId, Long productId);
	

}

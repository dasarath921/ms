package com.wishlist.dto.request;


public class WishListRequestDto {

	private Long user;
	
	private Long product;

	public Long getUser() {
		return user;
	}
	public void setUser(Long user) {
		this.user = user;
	}
	public Long getProduct() {
		return product;
	}
	public void setProduct(Long product) {
		this.product = product;
	}

	@Override
	public String toString() {
		return "WishListRequestDto [user=" + user + ", product=" + product + "]";
	}
	public WishListRequestDto(Long user, Long product) {
		super();
		this.user = user;
		this.product = product;
	}
		public WishListRequestDto() {
		super();
	}	

}

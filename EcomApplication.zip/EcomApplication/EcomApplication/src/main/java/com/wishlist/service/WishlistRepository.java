package com.wishlist.service;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wishlist.model.Wishlist;

@Repository
public interface WishlistRepository extends JpaRepository<Wishlist, Long>{

}

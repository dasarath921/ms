package com.wishlist.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.common.ApiResonse;
import com.wishlist.dto.request.WishListRequestDto;
import com.wishlist.dto.response.WishListResponseDto;
import com.wishlist.dto.response.WishlistResponseRetrive;
import com.wishlist.service.wishlistService;
import com.wishlist.service.impl.WishListServiceImpl;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
public class WishlistController {

	private final wishlistService wishlistService;

	public WishlistController(WishListServiceImpl wishlistService) {
		this.wishlistService = wishlistService;
	}

	@PostMapping("/wishlist/add")
	public ResponseEntity<ApiResonse<WishListResponseDto>> addToWishlist(@RequestBody WishListRequestDto item) {
		ApiResonse<WishListResponseDto> response = new ApiResonse<>();
		response.setData(wishlistService.createWishList(item));
		response.setMessage("Item added to wishlist successfully");
		response.setSuccess(true);
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}

	@GetMapping("/wishlist/{userId}")
	public ResponseEntity<List<WishlistResponseRetrive>> getWishListByUser(@PathVariable Long userId) {
		List<WishlistResponseRetrive> response = wishlistService.getUserWithList(userId);
		return ResponseEntity.ok(response);

	}

}

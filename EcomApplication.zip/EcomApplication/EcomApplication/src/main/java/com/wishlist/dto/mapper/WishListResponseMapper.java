package com.wishlist.dto.mapper;

import com.product.mapper.CategoryMapper;
import com.product.mapper.ProductMapper;
import com.wishlist.dto.response.WishlistResponseRetrive;
import com.wishlist.model.Wishlist;

public class WishListResponseMapper {

	public static WishlistResponseRetrive toResponseRetrive(Wishlist wishlist) {
		WishlistResponseRetrive response = new WishlistResponseRetrive();
		response.setProduct(ProductMapper.toProductResponseDto(wishlist.getProduct()));
		return response;
	}

}

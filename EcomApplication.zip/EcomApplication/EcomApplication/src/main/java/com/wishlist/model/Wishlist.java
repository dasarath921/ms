package com.wishlist.model;

import java.time.LocalDateTime;

import com.product.model.Product;
import com.user.entity.User;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "wishlist")
public class Wishlist {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;

	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product product;

	@Column(name = "created_at")
	private LocalDateTime localDateTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}

	public void setLocalDateTime(LocalDateTime localDateTime) {
		this.localDateTime = localDateTime;
	}

	@Override
	public String toString() {
		return "Wishlist [id=" + id + ", user=" + user + ", product=" + product + ", localDateTime=" + localDateTime
				+ "]";
	}

	public Wishlist(Long id, User user, Product product, LocalDateTime localDateTime) {
		super();
		this.id = id;
		this.user = user;
		this.product = product;
		this.localDateTime = localDateTime;
	}

	public Wishlist() {
		super();
	}

	public Wishlist(User user, Product product, LocalDateTime localDateTime) {
		super();
		this.user = user;
		this.product = product;
		this.localDateTime = localDateTime;
	}

}

package com.product.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.common.ApiResonse;
import com.product.dto.request.ProductRequestDto;
import com.product.dto.response.ProductResponseDto;
import com.product.service.ProductService;
import com.product.service.impl.ProductServiceImpl;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;

@RestController
public class ProductController {

	private final ProductService productService;

	public ProductController(ProductServiceImpl productServiceImpl) {
		this.productService = productServiceImpl;
	}

	@PostMapping("/product/create")
	public ResponseEntity<ApiResonse<ProductResponseDto>> createProduct(@Valid @NotNull ProductRequestDto dto) {
		ProductResponseDto response = productService.createProduct(dto);
		ApiResonse<ProductResponseDto> responsedto = new ApiResonse<>();
		responsedto.setData(response);
		responsedto.setMessage("Product Successfully Created");
		responsedto.setSuccess(true);
		return ResponseEntity.status(HttpStatus.CREATED).body(responsedto);
	}

}

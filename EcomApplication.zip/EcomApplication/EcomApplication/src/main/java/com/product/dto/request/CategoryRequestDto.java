package com.product.dto.request;

import jakarta.validation.constraints.NotNull;

public class CategoryRequestDto {

	@NotNull(message = "Category Name is required")
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "CategoryRequestDto [name=" + name + "]";
	}

	public CategoryRequestDto(@NotNull(message = "Category Name is required") String name) {
		super();
		this.name = name;
	}

	public CategoryRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}

}

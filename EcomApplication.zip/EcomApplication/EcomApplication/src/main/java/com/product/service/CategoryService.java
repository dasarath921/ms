package com.product.service;

import com.product.dto.request.CategoryRequestDto;
import com.product.dto.response.CategoryResponseDto;

public interface CategoryService {

	
	CategoryResponseDto createCategory(CategoryRequestDto dto);
	
	CategoryResponseDto SearchCategoy(String keyword);

}

package com.product.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.common.ApiResonse;
import com.product.dto.request.CategoryRequestDto;
import com.product.dto.response.CategoryResponseDto;
import com.product.service.CategoryService;
import com.product.service.impl.CategoryServiceImpl;

@RestController
public class CategoryController {

	private CategoryService categoryService;

	public CategoryController(CategoryServiceImpl categoryServiceImpl) {
		this.categoryService = categoryServiceImpl;
	}

	@PostMapping("category/create")
	public ResponseEntity<ApiResonse<CategoryResponseDto>> create(CategoryRequestDto categoryRequestDto) {
		ApiResonse<CategoryResponseDto> response = new ApiResonse<>();
		response.setData(categoryService.createCategory(categoryRequestDto));
		response.setMessage("Category is created successsfully");
		response.setSuccess(true);
		;
		return ResponseEntity.status(HttpStatus.CREATED).body(response);
	}

}

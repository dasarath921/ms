package com.product.mapper;

import com.product.dto.request.CategoryRequestDto;
import com.product.dto.response.CategoryResponseDto;
import com.product.model.Category;

public class CategoryMapper {

	public static Category toEntity(CategoryRequestDto category) {
		Category dto = new Category();
		dto.setName(category.getName());
		return dto;
	}

	public static CategoryResponseDto toCategoryResponse(Category category) {
		CategoryResponseDto dto = new CategoryResponseDto();
		dto.setCategoryId(category.getCategoryId());
		dto.setName(category.getName());
		return dto;

	}

}

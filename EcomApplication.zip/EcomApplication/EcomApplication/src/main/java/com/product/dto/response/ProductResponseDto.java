package com.product.dto.response;

import java.math.BigDecimal;


import com.product.model.Category;

public class ProductResponseDto {
	
	private Long productId;
	private String name;
	private String descriotion;
	private BigDecimal price;
	private Integer quntity;
	private Category category;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescriotion() {
		return descriotion;
	}
	public void setDescriotion(String descriotion) {
		this.descriotion = descriotion;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public Integer getQuntity() {
		return quntity;
	}
	public void setQuntity(Integer quntity) {
		this.quntity = quntity;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	@Override
	public String toString() {
		return "ProductResponseDto [productId=" + productId + ", name=" + name + ", descriotion=" + descriotion
				+ ", price=" + price + ", quntity=" + quntity + ", category=" + category + "]";
	}
	public ProductResponseDto(Long productId, String name, String descriotion, BigDecimal price, Integer quntity,
			Category category) {
		super();
		this.productId = productId;
		this.name = name;
		this.descriotion = descriotion;
		this.price = price;
		this.quntity = quntity;
		this.category = category;
	}
	public ProductResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	

}

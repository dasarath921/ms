package com.product.mapper;

import com.product.dto.request.ProductRequestDto;
import com.product.dto.response.ProductResponseDto;
import com.product.model.Product;

public class ProductMapper {

	public static Product toEntity(ProductRequestDto dto) {

		Product product = new Product();
		product.setDescriotion(dto.getDescription());
		product.setName(dto.getName());
		product.setPrice(dto.getPrice());
		product.setQuntity(dto.getQuntity());
		return product;

	}

	public static ProductResponseDto toProductResponseDto(Product p) {

		ProductResponseDto dto = new ProductResponseDto();
		dto.setProductId(p.getProductId());
		dto.setCategory(p.getCategory());
		dto.setName(p.getName());
		dto.setPrice(p.getPrice());
		dto.setQuntity(p.getQuntity());
		dto.setProductId(p.getProductId());
		return dto;

	}

}

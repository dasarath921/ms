package com.product.dto.request;

import java.math.BigDecimal;
import com.product.model.Category;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class ProductRequestDto {

	@NotNull(message = "Product name is required")
	private String name;
	@NotNull
	@DecimalMin(value = "0.1")
	private BigDecimal price;

	private String description;

	@NotNull
	@Min(value = 0)
	private Integer quntity;

	@NotNull
	private String categoryName;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getQuntity() {
		return quntity;
	}

	public void setQuntity(Integer quntity) {
		this.quntity = quntity;
	}

	public String getCategory() {
		return categoryName;
	}

	public void setCategory(String categoryName) {
		this.categoryName = categoryName;
	}

	public ProductRequestDto(@NotNull(message = "Product name is required") String name,
			@NotNull @DecimalMin("0.1") BigDecimal price, String description, @NotNull @Min(0) Integer quntity,
			@NotNull String categoryName) {
		super();
		this.name = name;
		this.price = price;
		this.description = description;
		this.quntity = quntity;
		this.categoryName = categoryName;
	}

	public ProductRequestDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ProductRequestDto [name=" + name + ", price=" + price + ", description=" + description + ", quntity="
				+ quntity + ", category=" + categoryName + "]";
	}

}

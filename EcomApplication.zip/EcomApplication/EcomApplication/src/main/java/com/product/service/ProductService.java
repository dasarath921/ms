package com.product.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.product.dto.request.ProductRequestDto;
import com.product.dto.response.ProductResponseDto;

@Service
public interface ProductService {

	ProductResponseDto createProduct(ProductRequestDto dto);

	List<ProductResponseDto> getAllProducts();

	ProductResponseDto getProductById(Long id);

	List<ProductResponseDto> searchProduct(String keyword);

}

package com.product.service.impl;

import org.springframework.stereotype.Service;

import com.product.Exception.CategoryNotFoundException;
import com.product.dto.request.CategoryRequestDto;
import com.product.dto.response.CategoryResponseDto;
import com.product.mapper.CategoryMapper;
import com.product.model.Category;
import com.product.repository.CategoryRepository;
import com.product.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

	private final CategoryRepository categoryRepository;

	public CategoryServiceImpl(CategoryRepository categoryRepository) {
		this.categoryRepository = categoryRepository;
	}

	@Override
	public CategoryResponseDto SearchCategoy(String keyword) {
		return categoryRepository.findByName(keyword).map(CategoryMapper::toCategoryResponse)
				.orElseThrow(() -> new CategoryNotFoundException("Category Not Found"));
	}

	@Override
	public CategoryResponseDto createCategory(CategoryRequestDto dto) {
		return CategoryMapper.toCategoryResponse(categoryRepository.save(new Category(dto.getName())));

	}

}

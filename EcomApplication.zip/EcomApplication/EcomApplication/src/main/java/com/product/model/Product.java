package com.product.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "products")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long productId;

	private String name;
	private String description;
	private BigDecimal price;
	
	@Column(name = "quantity")
	private Integer quntity;

	@ManyToOne
	@JoinColumn(name = "category_id")
	private Category category;

	@Column(name = "created_at")
	private LocalDateTime localDateTime;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescriotion() {
		return description;
	}

	public void setDescriotion(String descriotion) {
		this.description = descriotion;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Integer getQuntity() {
		return quntity;
	}

	public void setQuntity(Integer quntity) {
		this.quntity = quntity;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}

	public void setLocalDateTime(LocalDateTime localDateTime) {
		this.localDateTime = localDateTime;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", name=" + name + ", descriotion=" + description + ", price="
				+ price + ", quntity=" + quntity + ", category=" + category + ", localDateTime=" + localDateTime + "]";
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(Long productId, String name, String descriotion, BigDecimal price, Integer quntity,
			Category category, LocalDateTime localDateTime) {
		super();
		this.productId = productId;
		this.name = name;
		this.description = descriotion;
		this.price = price;
		this.quntity = quntity;
		this.category = category;
		this.localDateTime = localDateTime;
	}

	public Product(String name, String descriotion, BigDecimal price, Integer quntity, Category category,
			LocalDateTime localDateTime) {
		super();
		this.name = name;
		this.description = descriotion;
		this.price = price;
		this.quntity = quntity;
		this.category = category;
		this.localDateTime = localDateTime;
	}

}

package com.product.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.stereotype.Service;

import com.product.Exception.CategoryNotFoundException;
import com.product.Exception.ProductNotFoundException;
import com.product.dto.request.ProductRequestDto;
import com.product.dto.response.ProductResponseDto;
import com.product.mapper.ProductMapper;
import com.product.model.Category;
import com.product.model.Product;
import com.product.repository.CategoryRepository;
import com.product.repository.ProductRepository;
import com.product.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	private final ProductRepository productRepository;
	private final CategoryRepository categoryRepository;

	public ProductServiceImpl(ProductRepository productRepository, CategoryRepository categoryRepository) {
		this.productRepository = productRepository;
		this.categoryRepository = categoryRepository;
	}

	@Override
	public ProductResponseDto createProduct(ProductRequestDto dto) {
		Category c = categoryRepository.findByName(dto.getCategory())
				.orElseThrow(() -> new CategoryNotFoundException("Category Not Found"));

		Product product = ProductMapper.toEntity(dto);
		product.setLocalDateTime(LocalDateTime.now());
		product.setCategory(c);
		productRepository.save(product);
		ProductResponseDto response = ProductMapper.toProductResponseDto(product);
		return response;
	}

	@Override
	public List<ProductResponseDto> getAllProducts() {
		return productRepository.findAll().stream().map(ProductMapper::toProductResponseDto).toList();
	}

	@Override
	public ProductResponseDto getProductById(Long id) {
		return productRepository.findById(id).map(ProductMapper::toProductResponseDto)
				.orElseThrow(() -> new ProductNotFoundException("Product Not Found"));
	}

	@Override
	public List<ProductResponseDto> searchProduct(String keyword) {
		return productRepository.findByNameContainingIgnoreCase(keyword).stream()
				.map(ProductMapper::toProductResponseDto).toList();
	}

}

package com.product.dto.response;

public class CategoryResponseDto {

	private Long categoryId;

	private String name;

	public Long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Long categoryId) {
		this.categoryId = categoryId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "CategoryResponseDto [categoryId=" + categoryId + ", name=" + name + "]";
	}

	public CategoryResponseDto() {
		super();
		// TODO Auto-generated constructor stub
	}

}
